var structnode =
[
    [ "node", "structnode.html#a82669b7358b50bd8d7888d7df4ff8dfa", null ],
    [ "node", "structnode.html#aaa1a554d8c1d639df13e818d3d2e4b92", null ],
    [ "llink", "structnode.html#ab7d476c75161e9cff281b1dfc68d47f5", null ],
    [ "offset", "structnode.html#aeef7855fea382bfb671d7834aefa4b22", null ],
    [ "rlink", "structnode.html#a9162a39ef19fd18e9cd5e5aa9ab8dcdb", null ],
    [ "thread", "structnode.html#afd9ff5fa3c3ab99d07cac2a7ad9d14a6", null ],
    [ "val", "structnode.html#a707bf3f1eeeaf8974e7e8e90f7bfd6a1", null ],
    [ "x", "structnode.html#a64dd8b65a7d38c632a017d7f36444dbb", null ],
    [ "y", "structnode.html#ae944a3a75efb9856fa5c6f2221e2b49e", null ]
];