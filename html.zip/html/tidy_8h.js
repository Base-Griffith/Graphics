var tidy_8h =
[
    [ "display_tree", "tidy_8h.html#a32b96958c877c94e0f07be2c407b3cc4", null ],
    [ "petrify", "tidy_8h.html#a81dcfd78b13e2b9a30062cf513a04468", null ],
    [ "setup", "tidy_8h.html#a90e06195a55354792efbf4dbf8ccb69a", null ]
];