var searchData=
[
  ['scale_80',['SCALE',['../tidy_8cpp.html#a0cbea62f1ce2043dd08108e65ed8de1d',1,'tidy.cpp']]]
];
