var structextreme =
[
    [ "adr", "structextreme.html#a05fa93ec444cf3cac4689bd7a968d968", null ],
    [ "level", "structextreme.html#a80adaa7fa8a2fd6b51e092462628af3e", null ],
    [ "offset", "structextreme.html#a4a01f7889effe05776f9c7aab111452a", null ]
];