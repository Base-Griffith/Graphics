var tidy_8h =
[
    [ "display_tree", "tidy_8h.html#a7edd78857724519e5583882244b9217f", null ],
    [ "petrify", "tidy_8h.html#a81dcfd78b13e2b9a30062cf513a04468", null ],
    [ "setup", "tidy_8h.html#a90e06195a55354792efbf4dbf8ccb69a", null ]
];