var tidier__trees_2tidy_8h =
[
    [ "extreme", "structextreme.html", "structextreme" ],
    [ "draw_tree", "tidier__trees_2tidy_8h.html#ae2061fbf9c9faa6677bd295b0a95bd52", null ],
    [ "petrify", "tidier__trees_2tidy_8h.html#a81dcfd78b13e2b9a30062cf513a04468", null ],
    [ "setup_tdr", "tidier__trees_2tidy_8h.html#af8ac6b20cf48b25784d4e08bd5437074", null ],
    [ "tidy", "tidier__trees_2tidy_8h.html#a5b3c419df4060973d19148fe5f75b275", null ]
];