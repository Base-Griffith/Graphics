var tidier__trees_2bresenham_8h =
[
    [ "bres_circle", "tidier__trees_2bresenham_8h.html#a13f60629cc4e44eb67271ed9c25dd6ec", null ],
    [ "bres_line", "tidier__trees_2bresenham_8h.html#aece7b701388c2c9b4387986be7b23afc", null ],
    [ "circle_points", "tidier__trees_2bresenham_8h.html#a11870c8455f73ce3622dae2bd32b8061", null ],
    [ "draw_pixel", "tidier__trees_2bresenham_8h.html#a977e15e18955c5e85db9823473f7c66d", null ]
];