var trial2_8cpp =
[
    [ "display", "trial2_8cpp.html#a1e5b20fed15743656bb6d2e6a6ea6269", null ],
    [ "main", "trial2_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "reshape", "trial2_8cpp.html#a5333e4c58d8a1b0c16364be92a71aa2a", null ],
    [ "r", "trial2_8cpp.html#acab531abaa74a7e664e3986f2522b33a", null ],
    [ "screen_h", "trial2_8cpp.html#ad5226a6884c9edce3ee08d9fd235ca2f", null ],
    [ "screen_w", "trial2_8cpp.html#a4f3da26347df03b6570470ffa227f83e", null ],
    [ "x0", "trial2_8cpp.html#a97650a9c1395589a56789a90b5bf8d0c", null ],
    [ "x1", "trial2_8cpp.html#a97fcb0e1731b36905e90757f211b1340", null ],
    [ "y0", "trial2_8cpp.html#a6172bea3fd23fa3631c9e19851754db6", null ],
    [ "y1", "trial2_8cpp.html#a886daa12d11655f342168e87c7c0b1cb", null ]
];