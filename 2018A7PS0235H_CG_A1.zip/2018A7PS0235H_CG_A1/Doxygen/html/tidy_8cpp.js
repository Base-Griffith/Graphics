var tidy_8cpp =
[
    [ "MINSEP", "tidy_8cpp.html#a66cb98cee4ec0167b1ed423368bbb86d", null ],
    [ "RADIUS", "tidy_8cpp.html#aa4f8ea40228c3c3a9a7143b1d1ad8956", null ],
    [ "SCALE", "tidy_8cpp.html#a0cbea62f1ce2043dd08108e65ed8de1d", null ],
    [ "display_tree", "tidy_8cpp.html#a7edd78857724519e5583882244b9217f", null ],
    [ "petrify", "tidy_8cpp.html#a81dcfd78b13e2b9a30062cf513a04468", null ],
    [ "setup", "tidy_8cpp.html#ae1afac6076b43d605370e81fac4c2c35", null ]
];