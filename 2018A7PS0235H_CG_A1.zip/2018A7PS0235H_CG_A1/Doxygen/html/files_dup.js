var files_dup =
[
    [ "Documentation", "dir_f9dfd35b172a0e2036ace76497fb239b.html", null ],
    [ "bresenham.cpp", "bresenham_8cpp.html", "bresenham_8cpp" ],
    [ "bresenham.h", "bresenham_8h.html", "bresenham_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "tidy.cpp", "tidy_8cpp.html", "tidy_8cpp" ],
    [ "tidy.h", "tidy_8h.html", "tidy_8h" ],
    [ "toBST.cpp", "to_b_s_t_8cpp.html", "to_b_s_t_8cpp" ],
    [ "toBST.h", "to_b_s_t_8h.html", "to_b_s_t_8h" ]
];