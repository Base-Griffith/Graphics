var searchData=
[
  ['node_23',['node',['../structnode.html',1,'node'],['../structnode.html#a82669b7358b50bd8d7888d7df4ff8dfa',1,'node::node()'],['../structnode.html#aaa1a554d8c1d639df13e818d3d2e4b92',1,'node::node(int x)']]]
];
