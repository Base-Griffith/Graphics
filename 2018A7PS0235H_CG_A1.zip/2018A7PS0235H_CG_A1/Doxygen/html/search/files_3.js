var searchData=
[
  ['general_2emd_52',['General.md',['../_general_8md.html',1,'']]]
];
