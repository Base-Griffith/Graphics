var searchData=
[
  ['ptcolor_78',['ptColor',['../main_8cpp.html#a23edc943ab6dc2b4f4a4da98f0b9813f',1,'main.cpp']]]
];
