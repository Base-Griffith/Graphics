var searchData=
[
  ['radius_86',['RADIUS',['../tidy_8cpp.html#aa4f8ea40228c3c3a9a7143b1d1ad8956',1,'tidy.cpp']]]
];
