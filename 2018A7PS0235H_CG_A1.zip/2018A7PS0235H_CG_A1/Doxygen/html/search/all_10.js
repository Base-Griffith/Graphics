var searchData=
[
  ['unbalancedbst_42',['unbalancedBST',['../to_b_s_t_8cpp.html#a7f2c66ebf4b216563a26f6f967adcfd2',1,'unbalancedBST(struct node *head, int key):&#160;toBST.cpp'],['../to_b_s_t_8h.html#a2de8fe2b248490923b17157d2d6a7d81',1,'unbalancedBST(struct node *root, int key):&#160;toBST.cpp']]]
];
