var searchData=
[
  ['bres_5fcircle_60',['bres_circle',['../bresenham_8cpp.html#a2c421871dd005e106b6a6ce45b18fadc',1,'bres_circle(int x0, int y0, int r):&#160;bresenham.cpp'],['../bresenham_8h.html#a2c421871dd005e106b6a6ce45b18fadc',1,'bres_circle(int x0, int y0, int r):&#160;bresenham.cpp']]],
  ['bres_5fline_61',['bres_line',['../bresenham_8cpp.html#ac8f689b97e914e65be031773fcd15559',1,'bres_line(int x0, int y0, int x1, int y1):&#160;bresenham.cpp'],['../bresenham_8h.html#a099cd753803ffca32621174153e16d6f',1,'bres_line(int x1, int y1, int x2, int y2):&#160;bresenham.cpp']]]
];
