var searchData=
[
  ['y_115',['y',['../structnode.html#ae944a3a75efb9856fa5c6f2221e2b49e',1,'node']]],
  ['y0_116',['y0',['../tidier__trees_2main_8cpp.html#a6172bea3fd23fa3631c9e19851754db6',1,'y0():&#160;main.cpp'],['../trial2_8cpp.html#a6172bea3fd23fa3631c9e19851754db6',1,'y0():&#160;trial2.cpp']]],
  ['y1_117',['y1',['../tidier__trees_2main_8cpp.html#a886daa12d11655f342168e87c7c0b1cb',1,'y1():&#160;main.cpp'],['../trial2_8cpp.html#a886daa12d11655f342168e87c7c0b1cb',1,'y1():&#160;trial2.cpp']]]
];
