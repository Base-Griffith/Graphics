var searchData=
[
  ['general_20remarks_13',['General Remarks',['../_general.html',1,'']]],
  ['general_2emd_14',['General.md',['../_general_8md.html',1,'']]]
];
