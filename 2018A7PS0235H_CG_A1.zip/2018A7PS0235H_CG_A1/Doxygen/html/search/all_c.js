var searchData=
[
  ['petrify_25',['petrify',['../tidy_8cpp.html#a81dcfd78b13e2b9a30062cf513a04468',1,'petrify(struct node *t, int xpos):&#160;tidy.cpp'],['../tidy_8h.html#a81dcfd78b13e2b9a30062cf513a04468',1,'petrify(struct node *t, int xpos):&#160;tidy.cpp']]],
  ['ptcolor_26',['ptColor',['../main_8cpp.html#a23edc943ab6dc2b4f4a4da98f0b9813f',1,'main.cpp']]]
];
