var searchData=
[
  ['petrify_68',['petrify',['../tidy_8cpp.html#a81dcfd78b13e2b9a30062cf513a04468',1,'petrify(struct node *t, int xpos):&#160;tidy.cpp'],['../tidy_8h.html#a81dcfd78b13e2b9a30062cf513a04468',1,'petrify(struct node *t, int xpos):&#160;tidy.cpp']]]
];
