var searchData=
[
  ['node_118',['node',['../tidier__trees_2to_b_s_t_8h.html#af4aeda155dbe167f1c1cf38cb65bf324',1,'toBST.h']]]
];
