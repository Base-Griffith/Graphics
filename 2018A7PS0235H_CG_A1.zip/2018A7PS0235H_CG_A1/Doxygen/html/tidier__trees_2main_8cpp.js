var tidier__trees_2main_8cpp =
[
    [ "display", "tidier__trees_2main_8cpp.html#a1e5b20fed15743656bb6d2e6a6ea6269", null ],
    [ "init1", "tidier__trees_2main_8cpp.html#a5478c9cbd81f394fcff24f845b204234", null ],
    [ "main", "tidier__trees_2main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "reshape", "tidier__trees_2main_8cpp.html#a5333e4c58d8a1b0c16364be92a71aa2a", null ],
    [ "r", "tidier__trees_2main_8cpp.html#acab531abaa74a7e664e3986f2522b33a", null ],
    [ "x0", "tidier__trees_2main_8cpp.html#a97650a9c1395589a56789a90b5bf8d0c", null ],
    [ "x1", "tidier__trees_2main_8cpp.html#a97fcb0e1731b36905e90757f211b1340", null ],
    [ "y0", "tidier__trees_2main_8cpp.html#a6172bea3fd23fa3631c9e19851754db6", null ],
    [ "y1", "tidier__trees_2main_8cpp.html#a886daa12d11655f342168e87c7c0b1cb", null ]
];