var tidier__trees_2tidy_8cpp =
[
    [ "MINSEP", "tidier__trees_2tidy_8cpp.html#a66cb98cee4ec0167b1ed423368bbb86d", null ],
    [ "YSCALE", "tidier__trees_2tidy_8cpp.html#af8dc443bbe421682422f11ce80d943e8", null ],
    [ "draw_tree", "tidier__trees_2tidy_8cpp.html#a8f1d39cadd25f79deb8ba9d42fa60695", null ],
    [ "petrify", "tidier__trees_2tidy_8cpp.html#a81dcfd78b13e2b9a30062cf513a04468", null ],
    [ "setup_tdr", "tidier__trees_2tidy_8cpp.html#a30a73c71774dd933ba586eb4e5934e21", null ],
    [ "tidy", "tidier__trees_2tidy_8cpp.html#a5b3c419df4060973d19148fe5f75b275", null ],
    [ "rr", "tidier__trees_2tidy_8cpp.html#acb6b6c10ec7a11095abdedc5f3e1c017", null ]
];