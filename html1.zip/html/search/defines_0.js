var searchData=
[
  ['minsep_78',['MINSEP',['../tidy_8cpp.html#a66cb98cee4ec0167b1ed423368bbb86d',1,'tidy.cpp']]]
];
