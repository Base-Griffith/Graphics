var searchData=
[
  ['rlink_72',['rlink',['../structnode.html#a9162a39ef19fd18e9cd5e5aa9ab8dcdb',1,'node']]],
  ['root_73',['root',['../main_8cpp.html#a4c4817f1c5c2801859d1ded04bf23dce',1,'main.cpp']]]
];
