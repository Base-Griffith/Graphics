var searchData=
[
  ['offset_71',['offset',['../structnode.html#aeef7855fea382bfb671d7834aefa4b22',1,'node::offset()'],['../structextreme.html#a4a01f7889effe05776f9c7aab111452a',1,'extreme::offset()']]]
];
