var searchData=
[
  ['scale_27',['SCALE',['../tidy_8cpp.html#a0cbea62f1ce2043dd08108e65ed8de1d',1,'tidy.cpp']]],
  ['setup_28',['setup',['../tidy_8cpp.html#ae1afac6076b43d605370e81fac4c2c35',1,'setup(node *root, int level, extreme &amp;rightmost, extreme &amp;leftmost):&#160;tidy.cpp'],['../tidy_8h.html#a90e06195a55354792efbf4dbf8ccb69a',1,'setup(struct node *t, int level, struct extreme &amp;rmost, struct extreme &amp;lmost):&#160;tidy.cpp']]]
];
