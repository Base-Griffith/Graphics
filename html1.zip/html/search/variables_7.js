var searchData=
[
  ['y_77',['y',['../structnode.html#ae944a3a75efb9856fa5c6f2221e2b49e',1,'node']]]
];
